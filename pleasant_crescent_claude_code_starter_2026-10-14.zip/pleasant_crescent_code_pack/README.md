# Pleasant Crescent — Claude Code implementation and research starter

**Prepared 14 October 2026 | Proposed for Del Norte County / Crescent City family-resource mapping**

This is a **code-and-design starter kit**, not a deployed website and **not a bundle of downloaded geospatial imagery**. No Google tiles, county-owned GIS data, protected-species observations, private records or API secrets are included. All maps intended for local use must first pass the per-layer rights checklist. The `data/` directory contains only synthetic examples and a dataset manifest.

## What is inside

* `CLAUDE.md` — project instructions for Claude Code, including delivery constraints.
* `docs/` — scope, sequencing, ethical rules, roles, mobile experience, pricing and success conditions.
* `licenses/` — source-by-source rights matrix and approval checklist for a **self-contained atlas**.
* `architecture/` — layered map specification, data flow, provenance, event history and optional H3.
* `phoenix_selected/` — **positive, actionable, accurately qualified** components selected from the Phoenix repository. Includes exact short excerpts, adaptation notes and provenance to source documents. This does **not** assert a CRR-specific Bayes-optimal theorem or verified AI compute savings.
* `research/` — Bayesian decision theory, Free Energy Principle (FEP), Active Inference (AIF), and constrained optimization; specific test protocols.
* `backend/pc_core/` — executable, dependency-free Python reference implementation of belief updating, value of information, bounded attention policies, Fisher–Rao diagnostics, and lossless historical event retention.
* `backend/tests/` — unit tests. Run `PYTHONPATH=backend python -m unittest discover -s backend/tests -v` from repo root.
* `backend/examples/` — executable synthetic scenario and sample data, never published as genuine listings.
* `infrastructure/` — a small PostgreSQL/PostGIS Compose environment and starter schema.
* `frontend/` — a MapLibre layer adapter outline for *your* locally hosted map tiles; not production client code.
* `integrations/` — Daniel Friedman GIS compatibility questionnaire, export/import contracts, optional messaging strategy.

## Most important decisions

1. **Kim's contract is the baseline**: accessible mobile-first site, >= 40 **human-verified** entries, CMS, events, map or approved fallback, two organization-controlled admins, moderation, documentation, videos, two trainings and handoff. Eight weeks, $10,000 fixed planning envelope. Do not silently replace this with experimental AI research.
2. **MapLibre + Wagtail/Django + PostGIS** are the base. H3 is a derived spatial index for future aggregates, not a source of geography or road/travel time.
3. **No external map fetch per view**: produce your own properly licensed map tiles (vector roads + hydrography, raster orthophotos, terrain). Fetch data when *you choose* to ingest/update it; users view locally served tiles. Optionally provide Google View as a separate, officially integrated online-only tab, never cached/rehosted.
4. **Don't publish county GIS data without permission**: the county says its shared data are county-owned. Viewing or querying an ArcGIS service does not automatically grant redistribution rights.
5. **A small family directory is not a continual-learning GPU problem**. The LLM (if approved later) reads verified records; never retrains on user/private data by default.
6. **Bayes-optimal is conditional** on a declared prior, likelihood, feasible actions and utility. FEP/AIF is an optional normative decision formulation, not a proven improvement or unconditional guarantee.
7. **Keep event evidence** separately from compact working memories. An average can erase differences. Retention and deletion are governed by policy; never claim immutable storage is always appropriate.
8. **No child geolocation tracking or identifiable child profiles** in the proposed launch. Adults browse and filter resources by relevant age bands. Sensitive wildlife coordinates are protected.

## Suggested first Claude Code task

> Read `CLAUDE.md`, `docs/01_client_scope.md`, `licenses/layer_rights_matrix.csv`, `architecture/01_base_map.md`, and `architecture/02_data_and_memory.md`. Create a working Django/Wagtail/PostGIS/MapLibre vertical slice with **five clearly fictional** directory items and a public map; a contributor suggests an edit; an editor approves it; an admin checks the audit log. All writes must be server-authorized. First run the supplied reference unit tests, then run framework migrations and workflow tests. Document risks, licensing gaps, and what still needs the client to decide. Make no external GIS download or paid API call without explicit approval.

## Run reference checks

```bash
cd pleasant_crescent_code_pack
PYTHONPATH=backend python -m unittest discover -s backend/tests -v
PYTHONPATH=backend python backend/examples/demo_decisions.py
```

## Documentation/source status

This package selects **actionable positive contributions** from Phoenix but keeps required scope limitations. It distinguishes:
- source-verified fact;
- derived mathematical identity;
- proposed implementable design rule;
- experiment yet to be tested.

All source URLs and licence checkpoints appear in `licenses/` and `phoenix_selected/SOURCE_INDEX.md`.
