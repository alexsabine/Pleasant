"""Correct conditional information geometry; not a universal CRR event mechanism."""
from math import asin, sqrt, isfinite


def fisher_rao_bernoulli(p: float, q: float) -> float:
    """Intrinsic Fisher-Rao geodesic distance along Bernoulli family in radians."""
    if not (0 <= p <= 1 and 0 <= q <= 1):
        raise ValueError("Bernoulli parameters must lie in [0,1]")
    return 2 * abs(asin(sqrt(p)) - asin(sqrt(q)))


def arc_from_probabilities(points: list[float], sigma: float = 1.0) -> float:
    """Cumulative discrete FR arc divided by independently fixed sigma.

    This is sample-dependent path length, not a continuous theorem or circle.
    """
    if sigma <= 0 or not isfinite(sigma):
        raise ValueError("sigma must be positive and finite")
    return sum(fisher_rao_bernoulli(a, b) for a, b in zip(points, points[1:])) / sigma


def surplus_on_bernoulli_path(points: list[float], sigma: float = 1.0) -> float:
    """Path - endpoint geodesic; does NOT implement canonical circular rotor."""
    if not points:
        return 0.0
    c = arc_from_probabilities(points, sigma)
    d = fisher_rao_bernoulli(points[0], points[-1]) / sigma
    return max(0.0, c - d)  # round-off


def significant_belief_change(before: float, after: float, threshold: float) -> bool:
    """Proposed monitor feature, threshold selected separately from evaluation."""
    if threshold < 0:
        raise ValueError("threshold nonnegative")
    return fisher_rao_bernoulli(before, after) > threshold
